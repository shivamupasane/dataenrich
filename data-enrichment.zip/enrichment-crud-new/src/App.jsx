import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Home";
import MappingEditor from "./MappingEditor";
import { MantineProvider } from '@mantine/core';
import { DnDProvider, useDnD } from '../DnDContext';

let id = 0;
const getId = () => `dndnode_${id++}`;
const DnDFlow = () => {
  const reactFlowWrapper = useRef(null);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const { screenToFlowPosition } = useReactFlow();
  const [type] = useDnD();

  // Ensure correct nodeTypes match JSON
  const nodeTypes = {
    dataSource: DataSourceNode,
    filter: FilterNode,
    columnSelector: ColumnSelectorNode,
    addColumn: AddColumnNode,
    dataTarget: DataTargetNode
  };

  // Load initial nodes and edges on mount
  useEffect(() => {
    setNodes(jsonData.nodes);
    setEdges(jsonData.edges);
  }, []);

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    []
  );

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      if (!type) return;

      const position = screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const newNode = {
        id: getId(),
        type,
        position,
        data: { label: `${type} node` },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [screenToFlowPosition, type]
  );

  // Export function to download JSON with updated nodes and edges
  const exportToJson = () => {
    const jsonData = {
      nodes,
      edges
    };

    const jsonString = JSON.stringify(jsonData, null, 2);
    const blob = new Blob([jsonString], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "flow_data.json";
    link.click();
  };

  return (
    <div className="dndflow">
      <div className="reactflow-wrapper" ref={reactFlowWrapper}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          minZoom={0.2}
          maxZoom={4}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          onDrop={onDrop}
          onDragOver={onDragOver}
          fitView
          style={{ backgroundColor: "#F7F9FB" }}
        >
          <Controls />
          <Background />
        </ReactFlow>
      </div>
      
      {/* Export JSON Button */}
      <div style={{ padding: "10px", textAlign: "center" }}>
        <Button onClick={exportToJson} variant="outline" color="blue">
          Export JSON
        </Button>
      </div>

      <Sidebar />
    </div>
  );
};

export default function App() {
  return (
    <MantineProvider>
      <DnDProvider>
        <DnDFlow>
        <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/edit/:id" element={<MappingEditor />} />
      </Routes>
    </Router>
        </DnDFlow>
      </DnDProvider>
    </MantineProvider>
 
  );
}
